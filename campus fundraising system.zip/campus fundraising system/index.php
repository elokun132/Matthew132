<?php 
    define('TITLE',"campus fundraiser");
    include 'includes/header.php';
?>



<div id="philosophy">
    <hr>
    <br><br>
    <h3>Campus Fundraising System</h3>
    <br><br>
    <p>An Online Campus Fund Raising System is to alleviate the difficulties of manual fundraising of Small and large nonprofits of all sizes, are using the Internet to broaden their circles of influence and supporters. With the help of the Internet, even small or local organizations can connect with potential supporters anywhere in the world at any time. The possibilities for finding new donors online as well as the addition of a new communication channel for cultivating current donors excite fundraisers in particular. A continuing top priority is college and university fundraising. It is abundantly clear that an institution's capacity to raise funds from alumni, foundations, friends, parents, and other institutional partners is directly related to its capacity to realize its innovative but costly strategic goals. The increased public scrutiny of the cost of higher education has increased the reliance on funds raised. </p>
    
    </p><br><br><br>
    <br>
        <img src='_git assets/cover.png' style='width: 430px;'>
    </a>
    <hr>
</div>

<?php 
    include 'includes/footer.php';
?>