<?php

$SMTPuser = 'klik.official.website@gmail.com';
$SMTPpwd = 'example-password'; 
$SMTPtitle = "KLiK inc.";
