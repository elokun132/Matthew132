<?php

    // nav items   
    $navItems = array(
                        array(
                            'slug' => "index.php",
                            'title' => "Home"
                        ),
                        array(
                            'slug' => "contact.php",
                            'title' => "Contact Us"
                        ),
                    );
    
    $navItems_signedin = array(
                        array(
                            'slug' => "profile.php",
                            'title' => "My Profile"
                        ),
                        array(
                            'slug' => "edit-profile.php",
                            'title' => "Edit Profile"
                        ),
                        array(
                            'slug' => "index2.php",
                            'title' => "Project"
                        ),
                    );